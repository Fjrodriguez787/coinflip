#How its Made
HTML, CSS, JavaScript

You press a button and a random heads or tails shows up letting you know what you got

This can be used for making quick decisions with a simple heads or tails question

##If I had more time

I would make a visual representation of the coin flipping for a more realistic effect

###Lesson Learned
